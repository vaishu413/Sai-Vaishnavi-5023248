package observerPatternExample;

public interface Observer {
	 void update(double stockPrice);
}
