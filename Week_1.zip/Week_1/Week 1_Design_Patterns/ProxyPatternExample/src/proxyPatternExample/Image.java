package proxyPatternExample;

public interface Image {
	 void display();
}
