public class Main {
    public static void main(String[] args) {

        Inventory inventory = new Inventory();

  
        Product product1 = new Product("P001", "Laptop", 10, 999.99);
        Product product2 = new Product("P002", "Smartphone", 25, 499.99);
        Product product3 = new Product("P003", "Tablet", 15, 299.99);

        inventory.addProduct(product1);
        inventory.addProduct(product2);
        inventory.addProduct(product3);

  
        System.out.println("Added products:");
        System.out.println(inventory.getProduct("P001"));
        System.out.println(inventory.getProduct("P002"));
        System.out.println(inventory.getProduct("P003"));

   
        inventory.updateProduct("P002", 30, 479.99);
        System.out.println("\nUpdated product P002:");
        System.out.println(inventory.getProduct("P002"));

    
        inventory.deleteProduct("P003");
        System.out.println("\nAfter deleting product P003:");
        System.out.println("Product P003: " + inventory.getProduct("P003")); 

     
        Product retrievedProduct = inventory.getProduct("P001");
        System.out.println("\nRetrieved product P001:");
        System.out.println(retrievedProduct);

  
        System.out.println("\nCurrent inventory:");
        System.out.println(inventory.getProduct("P001"));
        System.out.println(inventory.getProduct("P002"));
    }
}
