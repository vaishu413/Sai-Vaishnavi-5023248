public class Main {
    public static void main(String[] args) {
        
        Order[] orders = {
            new Order("O001", "Alice", 150.75),
            new Order("O002", "Bob", 299.99),
            new Order("O003", "Charlie", 50.50),
            new Order("O004", "David", 400.00),
            new Order("O005", "Eve", 120.00)
        };

        
        System.out.println("Original Orders:");
        displayOrders(orders);

       
        System.out.println("\nOrders sorted by Bubble Sort:");
        BubbleSort.bubbleSort(orders);
        displayOrders(orders);

        
        orders = new Order[]{
            new Order("O001", "Alice", 150.75),
            new Order("O002", "Bob", 299.99),
            new Order("O003", "Charlie", 50.50),
            new Order("O004", "David", 400.00),
            new Order("O005", "Eve", 120.00)
        };

   
        System.out.println("\nOrders sorted by Quick Sort:");
        Quicksort.quickSort(orders, 0, orders.length - 1);
        displayOrders(orders);
    }

    
    private static void displayOrders(Order[] orders) {
        for (Order order : orders) {
            System.out.println(order);
        }
    }
}
