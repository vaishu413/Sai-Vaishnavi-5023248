import java.util.Arrays;

public class BinarySearch {
    // Binary search method
    public static Product binarySearch(Product[] products, String targetName) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            Product midProduct = products[mid];

            int comparison = midProduct.getProductName().compareTo(targetName);

            if (comparison == 0) {
                return midProduct; 
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1; 
            }
        }
        return null; 
    }


    public static void sortProductsByName(Product[] products) {
        Arrays.sort(products, (p1, p2) -> p1.getProductName().compareTo(p2.getProductName()));
    }
}
