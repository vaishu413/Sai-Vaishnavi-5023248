import java.util.Arrays;
public class Main {
    public static void main(String[] args) {
        
        Book[] books = {
            new Book("B001", "The Great Gatsby", "F. Scott Fitzgerald"),
            new Book("B002", "1984", "George Orwell"),
            new Book("B003", "To Kill a Mockingbird", "Harper Lee"),
            new Book("B004", "The Catcher in the Rye", "J.D. Salinger"),
            new Book("B005", "Pride and Prejudice", "Jane Austen")
        };

        
        System.out.println("Linear Search Example:");
        Book linearSearchResult = LinearSearch.linearSearchByTitle(books, "1984");
        if (linearSearchResult != null) {
            System.out.println("Found: " + linearSearchResult);
        } else {
            System.out.println("Book not found.");
        }

        
        Arrays.sort(books, (a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle())); 
        System.out.println("\nBinary Search Example:");
        Book binarySearchResult = BinarySearch.binarySearchByTitle(books, "The Catcher in the Rye");
        if (binarySearchResult != null) {
            System.out.println("Found: " + binarySearchResult);
        } else {
            System.out.println("Book not found.");
        }
    }
}
