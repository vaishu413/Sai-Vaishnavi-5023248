public class Main {
    public static void main(String[] args) {
        
        SingleLinkedList taskList = new SingleLinkedList();

        taskList.addTask(new Task("T001", "Design system architecture", "In Progress"));
        taskList.addTask(new Task("T002", "Implement user authentication", "Pending"));
        taskList.addTask(new Task("T003", "Setup database", "Completed"));

        
        System.out.println("All Tasks:");
        taskList.traverseTasks();

        
        System.out.println("\nSearching for Task ID 'T002':");
        Task searchResult = taskList.searchTask("T002");
        if (searchResult != null) {
            System.out.println("Task Found: " + searchResult);
        } else {
            System.out.println("Task with ID 'T002' not found.");
        }

       
        System.out.println("\nDeleting Task ID 'T001':");
        boolean deleteResult = taskList.deleteTask("T001");
        if (deleteResult) {
            System.out.println("Task with ID 'T001' deleted successfully.");
        } else {
            System.out.println("Task with ID 'T001' not found.");
        }

        
        System.out.println("\nTasks after deletion:");
        taskList.traverseTasks();
    }
}
